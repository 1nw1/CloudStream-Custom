package com.kodastream.app.data

import android.content.Context
import org.json.JSONArray

/** Small private search history, stored locally on-device (never synced). */
object SearchHistoryStore {
    private const val PREFS = "koda_search_history"
    private const val KEY = "queries"
    private const val LIMIT = 12

    fun get(context: Context): List<String> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val json = JSONArray(raw)
        (0 until json.length()).mapNotNull { json.optString(it).takeIf(String::isNotBlank) }
            .distinct().take(LIMIT)
    }.getOrDefault(emptyList())

    fun add(context: Context, query: String): List<String> {
        val value = query.trim()
        if (value.isEmpty()) return get(context)
        val updated = (listOf(value) + get(context).filterNot { it.equals(value, ignoreCase = true) }).take(LIMIT)
        val json = JSONArray()
        updated.forEach { json.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json.toString()).apply()
        return updated
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
